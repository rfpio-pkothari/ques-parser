import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import app from '../server.js';
import path from 'path';
import fs from 'fs';

describe('Server Tests', () => {
  const testFile = path.join(__dirname, '../test-files/sample.xlsx');
  
  beforeAll(() => {
    // Create uploads directory if it doesn't exist
    const uploadsDir = path.join(__dirname, '../../uploads');
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir, { recursive: true });
    }
  });

  afterAll(() => {
    // Cleanup test files
    const uploadsDir = path.join(__dirname, '../../uploads');
    fs.readdirSync(uploadsDir).forEach(file => {
      fs.unlinkSync(path.join(uploadsDir, file));
    });
  });

  it('should serve static files', async () => {
    const res = await request(app).get('/');
    expect(res.status).toBe(200);
    expect(res.type).toContain('text/html');
  });

  it('should handle file upload', async () => {
    const res = await request(app)
      .post('/api/upload')
      .attach('file', testFile);
    
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.questions).toBeDefined();
  });

  it('should handle missing file', async () => {
    const res = await request(app)
      .post('/api/upload')
      .send();
    
    expect(res.status).toBe(400);
    expect(res.body.error).toBe('No file uploaded');
  });

  it('should handle invalid file type', async () => {
    const res = await request(app)
      .post('/api/upload')
      .attach('file', 'test.txt');
    
    expect(res.status).toBe(400);
    expect(res.body.error).toContain('Only Excel files');
  });
});