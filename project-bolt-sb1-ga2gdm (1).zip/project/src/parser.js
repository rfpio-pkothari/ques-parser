import xlsx from 'xlsx';
import fs from 'fs';

const SECTION_INDICATORS = [
  'section',
  'category',
  'part',
  'group',
  'module',
  'chapter',
  'area'
];

const isSectionHeader = (cell) => {
  if (!cell) return false;
  const value = cell.toString().trim();
  
  // Check common section patterns
  if (value === value.toUpperCase() && value.length > 3) return true;
  if (SECTION_INDICATORS.some(indicator => value.toLowerCase().startsWith(indicator))) return true;
  if (/^[0-9]+\.[0-9]*\s+[A-Z]/.test(value)) return true; // Numbered sections like "1.0 OVERVIEW"
  if (/^[A-Z][A-Z\s]{2,}/.test(value)) return true; // All caps words
  
  return false;
};

const isQuestion = (cell) => {
  if (!cell) return false;
  const value = cell.toString().trim();
  
  // Check question patterns
  if (/^Q[0-9]+\.?\s+/i.test(value)) return true; // Q1, Q2, etc.
  if (/^[0-9]+\.?\s*\)?/.test(value)) return true; // 1., 1), etc.
  if (/\?$/.test(value)) return true; // Ends with question mark
  if (/^(describe|explain|provide|list|specify|detail|outline|what|how|when|where|why|who|which)/i.test(value)) return true;
  
  return value.length > 10; // Likely a question if it's a longer text
};

const cleanText = (text) => {
  if (!text) return '';
  return text.toString()
    .replace(/\r\n|\r|\n/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
};

export const parseExcel = async (filePath) => {
  const logs = [];
  const addLog = (message, type = 'info') => {
    logs.push({
      timestamp: new Date().toISOString(),
      type,
      message
    });
  };

  try {
    addLog('Starting to read Excel file...');
    const workbook = xlsx.readFile(filePath, {
      cellFormula: false,
      cellHTML: false,
      cellText: true
    });
    
    addLog(`Successfully loaded workbook with ${workbook.SheetNames.length} worksheets`);

    const result = {};
    const stats = {
      total_worksheets: workbook.SheetNames.length,
      total_sections: 0,
      total_questions: 0,
      questions_per_section: {}
    };

    for (const sheetName of workbook.SheetNames) {
      addLog(`Processing worksheet: ${sheetName}`);
      const worksheet = workbook.Sheets[sheetName];
      const data = xlsx.utils.sheet_to_json(worksheet, { header: 1 });
      result[sheetName] = [];
      
      let currentSection = null;
      let rowCount = 0;
      let questionCount = 0;

      for (const row of data) {
        rowCount++;
        if (!row.length || row.every(cell => !cell)) continue;

        const firstCell = cleanText(row[0]);
        const secondCell = cleanText(row[1]);
        
        if (isSectionHeader(firstCell)) {
          currentSection = firstCell;
          result[sheetName].push({
            section: currentSection,
            questions: []
          });
          stats.total_sections++;
          stats.questions_per_section[currentSection] = 0;
          addLog(`Found section: "${currentSection}" in worksheet "${sheetName}"`);
        } else if (currentSection) {
          // Check both first and second cells for questions
          const questionText = isQuestion(firstCell) ? firstCell : 
                             isQuestion(secondCell) ? secondCell : null;
          
          if (questionText) {
            const questionObj = {
              text: questionText,
              number: ++questionCount
            };
            
            // Add additional context if available
            if (row.length > 1 && !isQuestion(secondCell)) {
              questionObj.context = cleanText(secondCell);
            }
            
            result[sheetName][result[sheetName].length - 1].questions.push(questionObj);
            stats.total_questions++;
            stats.questions_per_section[currentSection]++;
            
            if (questionCount % 10 === 0) {
              addLog(`Processed ${questionCount} questions in worksheet "${sheetName}"`);
            }
          }
        }
      }
      
      addLog(`Completed processing ${rowCount} rows in worksheet "${sheetName}"`);
      addLog(`Found ${questionCount} questions in worksheet "${sheetName}"`);
    }

    // Calculate additional statistics
    stats.average_questions_per_section = Math.round(stats.total_questions / stats.total_sections);
    
    addLog('Processing completed successfully');
    addLog(`Total Statistics:
    - Worksheets: ${stats.total_worksheets}
    - Sections: ${stats.total_sections}
    - Questions: ${stats.total_questions}
    - Average Questions per Section: ${stats.average_questions_per_section}`);

    // Clean up the uploaded file
    fs.unlinkSync(filePath);
    addLog('Cleaned up temporary files');

    return {
      success: true,
      data: result,
      stats,
      logs
    };
  } catch (error) {
    addLog(`Error occurred: ${error.message}`, 'error');
    // Clean up the uploaded file in case of error
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      addLog('Cleaned up temporary files after error');
    }
    throw error;
  }
};