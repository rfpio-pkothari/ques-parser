export const UPLOAD_MAX_SIZE = 16 * 1024 * 1024; // 16MB

export const MIME_TYPES = {
  XLSX: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  XLS: 'application/vnd.ms-excel',
  BINARY: 'application/octet-stream'
};

export const FILE_EXTENSIONS = ['.xlsx', '.xls'];

export const ERROR_MESSAGES = {
  NO_FILE: 'No file uploaded',
  INVALID_FILE: 'Only Excel files (.xlsx, .xls) are allowed',
  FILE_TOO_LARGE: 'File size exceeds 16MB limit',
  PARSE_ERROR: 'Error parsing Excel file',
  NO_DATA: 'No parsed data available'
};