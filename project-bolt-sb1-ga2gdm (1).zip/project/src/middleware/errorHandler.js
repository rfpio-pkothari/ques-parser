import { Logger } from '../utils/logger.js';

const logger = new Logger();

export const errorHandler = (err, req, res, next) => {
  logger.add(`Error: ${err.message}`, 'error');
  
  // Ensure proper JSON response
  res.setHeader('Content-Type', 'application/json');

  // Handle specific error types
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({
      success: false,
      error: 'File size exceeds 16MB limit'
    });
  }

  if (err.name === 'ValidationError') {
    return res.status(400).json({
      success: false,
      error: err.message
    });
  }

  // Default error response
  res.status(err.status || 500).json({
    success: false,
    error: err.message || 'Internal server error'
  });
};