import multer from 'multer';
import { validateExcelFile } from '../utils/fileHandler.js';
import { UPLOAD_MAX_SIZE } from '../config/constants.js';

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix);
  }
});

export const upload = multer({
  storage: storage,
  limits: {
    fileSize: UPLOAD_MAX_SIZE
  },
  fileFilter: (req, file, cb) => {
    if (validateExcelFile(file)) {
      cb(null, true);
    } else {
      cb(new Error('Only Excel files (.xlsx, .xls) are allowed'));
    }
  }
});