import { WorkbookParser } from './workbookParser.js';
import { ExcelColumnFinder } from './excelColumnFinder.js';
import { QuestionExtractor } from './questionExtractor.js';
import { Logger } from '../utils/logger.js';
import { ProcessingSteps } from '../utils/processingSteps.js';
import { WorksheetFilter } from '../utils/worksheetFilter.js';

export class ExcelParser {
  constructor() {
    this.logger = new Logger();
    this.steps = new ProcessingSteps(this.logger);
    this.workbookParser = new WorkbookParser(this.logger);
    this.columnFinder = new ExcelColumnFinder(this.logger);
    this.questionExtractor = new QuestionExtractor(this.logger);
  }

  async parse(filePath) {
    try {
      if (!filePath) {
        throw new Error('No file provided');
      }

      this.steps.addStep(
        "Starting Analysis",
        "Beginning to analyze your Excel file to identify questions and requirements"
      );

      let workbook;
      try {
        workbook = this.workbookParser.parseWorkbook(filePath);
        if (!workbook?.SheetNames?.length) {
          throw new Error('Invalid Excel file: No worksheets found');
        }
      } catch (error) {
        throw new Error(`Failed to read Excel file: ${error.message}`);
      }
      
      this.steps.addStep(
        "File Loading Complete",
        `Successfully loaded Excel file with ${workbook.SheetNames.length} worksheets`
      );

      const totalQuestions = [];
      const totalSections = new Set();
      let validWorksheets = 0;
      
      this.steps.addStep(
        "Processing Worksheets",
        "Analyzing each worksheet to identify sections and questions"
      );

      // First pass - identify valid worksheets
      const validSheets = workbook.SheetNames.filter(sheetName => {
        const worksheet = workbook.Sheets[sheetName];
        const { rows } = this.workbookParser.getWorksheetData(worksheet);
        return rows && rows.length > 0;
      });

      if (validSheets.length === 0) {
        throw new Error('No valid worksheets found for processing. Please check the file format.');
      }

      // Second pass - process valid worksheets
      for (const sheetName of validSheets) {
        try {
          this.steps.addSubStep(`Processing worksheet: ${sheetName}`);
          
          const worksheet = workbook.Sheets[sheetName];
          const { rows } = this.workbookParser.getWorksheetData(worksheet);
          
          // Find columns with validation
          const columns = this.columnFinder.findColumns(rows[0]);
          
          // Extract questions and sections
          const { questions, sections } = this.questionExtractor.extract(rows, columns);
          
          if (questions.length > 0) {
            questions.forEach(q => {
              q.worksheet = sheetName;
              totalQuestions.push(q);
            });
            sections.forEach(s => totalSections.add(s));
            validWorksheets++;
            this.steps.addSubStep(`Found ${questions.length} questions in worksheet: ${sheetName}`);
          } else {
            this.steps.addSubStep(`No valid questions found in worksheet: ${sheetName}`);
          }
        } catch (error) {
          this.logger.add(`Error in worksheet ${sheetName}: ${error.message}`, 'warning');
          this.steps.addSubStep(`Error processing worksheet ${sheetName}: ${error.message}`, 'warning');
          continue;
        }
      }

      if (totalQuestions.length === 0) {
        throw new Error('No questions were found in the Excel file. Please check the file content.');
      }

      const stats = {
        total_worksheets: workbook.SheetNames.length,
        total_sections: totalSections.size,
        total_questions: totalQuestions.length
      };

      this.steps.addStep(
        "Analysis Complete",
        `Successfully processed ${stats.total_questions} questions across ${stats.total_sections} sections`
      );

      return {
        success: true,
        questions: totalQuestions,
        stats,
        steps: this.steps.getSteps()
      };

    } catch (error) {
      this.logger.add(`Parser error: ${error.message}`, 'error');
      this.steps.addStep("Error Occurred", error.message, 'error');
      this.steps.markError();
      
      return {
        success: false,
        error: error.message,
        questions: [],
        stats: {
          total_worksheets: 0,
          total_sections: 0,
          total_questions: 0
        },
        steps: this.steps.getSteps()
      };
    }
  }
}