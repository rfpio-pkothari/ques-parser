import { HfInference } from '@huggingface/inference';

export class NLPAnalyzer {
  constructor(apiKey) {
    this.hf = new HfInference(apiKey);
    this.model = "naver-clova-ix/donut-base-finetuned-rvlcdip";
  }

  async analyzeText(text) {
    try {
      const result = await this.hf.textClassification({
        model: this.model,
        inputs: text
      });

      // Analyze if the text is a requirement/question
      const isRequirement = result.some(r => 
        r.label.includes('requirement') || 
        r.label.includes('question') ||
        r.label.includes('instruction')
      );

      // Calculate confidence based on classification scores
      const confidence = result.reduce((max, r) => 
        r.score > max ? r.score : max, 0);

      return {
        isRequirement,
        confidence,
        classification: result
      };
    } catch (error) {
      console.error('NLP analysis error:', error);
      return {
        isRequirement: false,
        confidence: 0,
        classification: []
      };
    }
  }
}