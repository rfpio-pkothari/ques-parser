import { Logger } from '../utils/logger.js';

export class ExcelColumnFinder {
  constructor(logger = new Logger()) {
    this.logger = logger;
  }

  findColumns(headers) {
    try {
      if (!headers || !Array.isArray(headers)) {
        this.logger.add('Invalid headers array', 'error');
        return this.getDefaultColumns();
      }

      // First try to find columns by exact header matches
      const columns = {
        question: this.findQuestionColumn(headers),
        category: this.findCategoryColumn(headers),
        id: this.findIdColumn(headers)
      };

      // If no question column found, try to detect format
      if (columns.question === -1) {
        if (this.isCAIQFormat(headers)) {
          this.logger.add('Detected CAIQ format, using default column mapping');
          return this.getCAIQColumns();
        } else if (this.isRFPFormat(headers)) {
          this.logger.add('Detected RFP format, using default column mapping');
          return this.getRFPColumns();
        }
      }

      // If still no columns found, use default mapping
      if (columns.question === -1) {
        this.logger.add('Using default column mapping');
        return this.getDefaultColumns();
      }

      this.logger.add(`Found columns: Question=${columns.question}, Category=${columns.category}, ID=${columns.id}`);
      return columns;
    } catch (error) {
      this.logger.add(`Error finding columns: ${error.message}`, 'error');
      return this.getDefaultColumns();
    }
  }

  isCAIQFormat(headers) {
    const firstHeader = String(headers[0] || '').toLowerCase().trim();
    return firstHeader.includes('control') || /^[a-z&]+-\d+/.test(firstHeader);
  }

  isRFPFormat(headers) {
    const headerStr = headers.join(' ').toLowerCase();
    return headerStr.includes('requirement') || 
           headerStr.includes('question') || 
           headerStr.includes('response');
  }

  getCAIQColumns() {
    return { question: 1, category: 0, id: 0 };
  }

  getRFPColumns() {
    return { question: 1, category: 0, id: 0 };
  }

  getDefaultColumns() {
    return { question: 1, category: 0, id: 0 };
  }

  findQuestionColumn(headers) {
    const questionHeaders = [
      'question',
      'requirement',
      'control question',
      'assessment question',
      'control specification',
      'description',
      'requirements'
    ];

    return this.findColumnByHeaders(headers, questionHeaders);
  }

  findCategoryColumn(headers) {
    const categoryHeaders = [
      'category',
      'section',
      'domain',
      'control domain',
      'control category',
      'control group',
      'group',
      'area'
    ];

    return this.findColumnByHeaders(headers, categoryHeaders);
  }

  findIdColumn(headers) {
    const idHeaders = [
      'question id',
      'id',
      'control id',
      'requirement id',
      'cid',
      'reference',
      'number'
    ];

    return this.findColumnByHeaders(headers, idHeaders);
  }

  findColumnByHeaders(headers, searchHeaders) {
    try {
      // First try exact matches
      for (let i = 0; i < headers.length; i++) {
        const header = String(headers[i] || '').toLowerCase().trim();
        if (searchHeaders.includes(header)) {
          return i;
        }
      }

      // Then try partial matches
      for (let i = 0; i < headers.length; i++) {
        const header = String(headers[i] || '').toLowerCase().trim();
        if (searchHeaders.some(h => header.includes(h))) {
          return i;
        }
      }

      return -1;
    } catch (error) {
      this.logger.add(`Error in findColumnByHeaders: ${error.message}`, 'error');
      return -1;
    }
  }
}