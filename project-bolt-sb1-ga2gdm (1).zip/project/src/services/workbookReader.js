import xlsx from 'xlsx';
import { Logger } from '../utils/logger.js';

export class WorkbookReader {
  constructor(logger = new Logger()) {
    this.logger = logger;
  }

  readWorkbook(filePath) {
    this.logger.add('Reading Excel workbook...');
    
    const workbook = xlsx.readFile(filePath, {
      cellFormula: false,
      cellHTML: false,
      cellText: true
    });

    this.logger.add(`Successfully read workbook with ${workbook.SheetNames.length} worksheets`);
    return workbook;
  }

  getColumnIndices(worksheet) {
    const range = xlsx.utils.decode_range(worksheet['!ref']);
    let categoryCol = -1;
    let requirementCol = -1;

    // First pass: look for exact column header matches
    for (let c = range.s.c; c <= range.e.c; c++) {
      const headerRef = xlsx.utils.encode_cell({ r: range.s.r, c });
      const cell = worksheet[headerRef];
      if (!cell || !cell.v) continue;

      const value = cell.v.toString().toLowerCase().trim();
      
      if (value === 'category') categoryCol = c;
      if (value === 'requirement') requirementCol = c;
    }

    // Second pass: if requirement column not found, look for similar headers
    if (requirementCol === -1) {
      for (let c = range.s.c; c <= range.e.c; c++) {
        const headerRef = xlsx.utils.encode_cell({ r: range.s.r, c });
        const cell = worksheet[headerRef];
        if (!cell || !cell.v) continue;

        const value = cell.v.toString().toLowerCase().trim();
        
        if (value.includes('requirement') || 
            value.includes('question') || 
            value.includes('description')) {
          requirementCol = c;
          break;
        }
      }
    }

    // If still not found, assume the third column is requirements
    if (requirementCol === -1) {
      requirementCol = 2; // 0-based index, so this is the third column
      this.logger.add('No requirement column header found, using third column');
    }

    if (categoryCol === -1) {
      categoryCol = 1; // Assume second column is category if not found
      this.logger.add('No category column header found, using second column');
    }

    this.logger.add(`Found columns - Category: ${categoryCol}, Requirement: ${requirementCol}`);
    return { categoryCol, requirementCol, range };
  }

  getCellValue(worksheet, row, col) {
    const cellRef = xlsx.utils.encode_cell({ r: row, c: col });
    const cell = worksheet[cellRef];
    if (!cell) return '';
    
    // Handle different cell types
    if (cell.t === 'n') return cell.v.toString();
    if (cell.t === 'b') return cell.v ? 'true' : 'false';
    if (cell.t === 'd') return cell.w || cell.v;
    return cell.v ? cell.v.toString() : '';
  }
}