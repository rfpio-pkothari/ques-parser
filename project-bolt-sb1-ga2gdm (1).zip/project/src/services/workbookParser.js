import xlsx from 'xlsx';
import { Logger } from '../utils/logger.js';

export class WorkbookParser {
  constructor(logger = new Logger()) {
    this.logger = logger;
  }

  parseWorkbook(filePath) {
    try {
      const workbook = xlsx.readFile(filePath, {
        cellFormula: false,
        cellHTML: false,
        cellText: true
      });

      if (!workbook || !workbook.SheetNames || workbook.SheetNames.length === 0) {
        throw new Error('Invalid Excel file: No worksheets found');
      }

      return workbook;
    } catch (error) {
      this.logger.add(`Error reading Excel file: ${error.message}`, 'error');
      throw error;
    }
  }

  getWorksheetData(worksheet) {
    if (!worksheet['!ref']) {
      return { rows: [], range: null };
    }

    const range = xlsx.utils.decode_range(worksheet['!ref']);
    const rows = [];

    for (let r = range.s.r; r <= range.e.r; r++) {
      const row = [];
      for (let c = range.s.c; c <= range.e.c; c++) {
        const cellRef = xlsx.utils.encode_cell({ r, c });
        const cell = worksheet[cellRef];
        row.push(cell ? cell.v : undefined);
      }
      rows.push(row);
    }

    return { rows, range };
  }
}