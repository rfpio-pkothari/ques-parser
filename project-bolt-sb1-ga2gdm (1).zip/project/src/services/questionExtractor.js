import { QuestionDetector } from '../utils/questionDetector.js';
import { TextCleaner } from '../utils/textCleaner.js';
import { ConfidenceCalculator } from '../utils/confidenceCalculator.js';
import { SectionDetector } from '../utils/sectionDetector.js';

export class QuestionExtractor {
  constructor(logger) {
    this.logger = logger;
    this.processedQuestions = new Set();
  }

  extract(rows, columns) {
    if (!Array.isArray(rows) || rows.length === 0) {
      this.logger.add('No rows to process', 'warning');
      return { questions: [], sections: new Set() };
    }

    const questions = [];
    const sections = new Set();
    let currentSection = 'General';
    let questionNumber = 1;

    try {
      // Skip header row
      for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        if (!row || row.every(cell => !cell)) continue;

        // Get the question ID and text
        const questionId = this.getQuestionId(row[columns.id]);
        const questionText = this.getQuestionText(row[columns.question]);
        const categoryText = this.getCategoryText(row[columns.category]);

        // Process section if valid
        if (categoryText && SectionDetector.validateSection(categoryText)) {
          currentSection = TextCleaner.clean(categoryText);
          sections.add(currentSection);
          continue;
        }

        // Process question if valid
        if (questionText && QuestionDetector.isQuestion(questionText, questionId)) {
          const cleanText = TextCleaner.clean(questionText);
          const questionKey = `${currentSection}:${cleanText}`;

          // Skip duplicates
          if (this.processedQuestions.has(questionKey)) {
            continue;
          }

          // Skip if the text is the same as the current section
          if (cleanText.toLowerCase() === currentSection.toLowerCase()) {
            continue;
          }

          questions.push({
            id: questionId || `Q${questionNumber}`,
            section: currentSection,
            questionNumber: questionNumber++,
            text: cleanText,
            confidence: ConfidenceCalculator.calculate(cleanText)
          });

          this.processedQuestions.add(questionKey);
        }
      }
    } catch (error) {
      this.logger.add(`Error extracting questions: ${error.message}`, 'error');
    }

    return { questions, sections };
  }

  getQuestionId(cell) {
    if (!cell) return null;
    const value = TextCleaner.clean(cell);
    // Match CAIQ format (e.g., A&A-01.1) or other common formats
    const match = value.match(/^[A-Z&]+-\d+\.\d+$/) || 
                 value.match(/^[A-Z0-9-]+$/) ||
                 value.match(/^\d+(\.\d+)*$/);
    return match ? match[0] : null;
  }

  getQuestionText(cell) {
    if (!cell) return null;
    const text = TextCleaner.clean(cell);
    // More thorough validation
    if (text.length < 5 || /^(yes|no|n\/a)$/i.test(text)) {
      return null;
    }
    return text;
  }

  getCategoryText(cell) {
    if (!cell) return null;
    const text = TextCleaner.clean(cell);
    return text.length > 0 ? text : null;
  }
}