export class QuestionValidator {
  constructor() {
    this.sectionCache = new Set();
    this.questionCache = new Set();
  }

  isValidQuestion(text, section) {
    if (!text || typeof text !== 'string') return false;
    
    const cleanText = text.trim();
    
    // Skip if too short
    if (cleanText.length < 5) return false;
    
    // Skip URLs and simple responses
    if (this.isSkippable(cleanText)) return false;

    // Skip if it's a duplicate
    const key = `${section}:${cleanText}`;
    if (this.questionCache.has(key)) {
      return false;
    }

    // For CAIQ format, accept any non-empty text that's not a header
    if (cleanText.length > 10 && !this.isHeader(cleanText)) {
      this.questionCache.add(key);
      return true;
    }

    return false;
  }

  isValidSection(text) {
    if (!text || typeof text !== 'string') return false;
    
    const cleanText = text.trim();
    
    // Skip empty or too short sections
    if (cleanText.length < 2) return false;

    // For CAIQ format, accept control IDs as section markers
    if (/^[A-Z&]+-\d+/.test(cleanText)) {
      const section = cleanText.split('-')[0];
      if (!this.sectionCache.has(section)) {
        this.sectionCache.add(section);
        return true;
      }
    }

    return false;
  }

  isSkippable(text) {
    const skipPatterns = [
      /^(yes|no|n\/a|true|false)$/i,
      /^https?:\/\//i,
      /^www\./i,
      /^[0-9.]+$/,
      /^[-–—]+$/,
      /^$/
    ];

    return skipPatterns.some(pattern => pattern.test(text.trim()));
  }

  isHeader(text) {
    const headerPatterns = [
      /^section\s+\d+/i,
      /^category\s+\d+/i,
      /^control\s+\d+/i,
      /^[A-Z\s&]{3,}$/,
      /^(title|description|notes?|comments?):\s*$/i
    ];

    return headerPatterns.some(pattern => pattern.test(text.trim()));
  }

  calculateConfidence(text) {
    let score = 0.5; // Base confidence

    // Increase confidence based on various factors
    if (text.includes('?')) score += 0.2;
    if (/^(are|is|does|do|can|will|should|must|how|what|when|where|why|which)/i.test(text)) score += 0.2;
    if (text.length > 50) score += 0.1;
    if (/\b(shall|must|should|require|ensure|verify|validate|implement)\b/i.test(text)) score += 0.1;
    
    return Math.min(0.95, score);
  }
}