// Question identification patterns
export const QUESTION_PATTERNS = [
  /^(what|how|when|where|why|who|which)/i,
  /^(describe|explain|provide|list|specify|detail)/i,
  /^(do|does|can|will|should|would|could|is|are|have)/i,
  /\?$/,
  /^ability\s+to\s+/i,
  /^must\s+(have|be|provide)/i,
  /^should\s+(have|be|provide)/i,
  /^support\s+for\s+/i,
  /^is\s+there\s+/i,
  /^are\s+there\s+/i,
  /^does\s+the\s+/i
];

// Common requirement verbs
export const REQUIREMENT_VERBS = [
  'provide',
  'create',
  'enable',
  'allow',
  'support',
  'implement',
  'configure',
  'manage',
  'maintain',
  'generate',
  'process',
  'handle',
  'display',
  'store',
  'validate',
  'verify',
  'ensure',
  'control',
  'monitor',
  'track',
  'analyze',
  'report',
  'integrate',
  'sync',
  'export',
  'import',
  'setup',
  'assign',
  'establish',
  'document',
  'approve',
  'communicate',
  'apply',
  'evaluate',
  'review',
  'update',
  'conduct',
  'perform',
  'define',
  'remediate',
  'assess'
];

// Priority indicators for confidence calculation
export const PRIORITY_INDICATORS = [
  'must have',
  'required',
  'mandatory',
  'essential',
  'critical',
  'high priority',
  'necessary',
  'important',
  'key requirement',
  'shall',
  'will'
];

// Skip patterns for non-relevant content
export const SKIP_PATTERNS = [
  /^(notes?|comments?|description|details?|summary|title|name|reference):\s*$/i,
  /^additional\s+information$/i,
  /^\(.*\)$/,
  /^n\/?a$/i,
  /^none$/i,
  /^https?:\/\//i,
  /^www\./i,
  /^true$/i,
  /^false$/i,
  /^yes$/i,
  /^no$/i,
  /^[-–—]+$/,
  /^[0-9.]+$/
];

// Section patterns
export const SECTION_PATTERNS = [
  /^[A-Z][A-Z\s]{2,}$/,  // ALL CAPS
  /^[A-Z][a-z]+(\s*-\s*[A-Z][a-z\s&]+)+/, // Title-Case With Hyphens
  /^[IVX]+\.\s+/,  // Roman numerals
  /^[A-Z][a-z\s&]+$/, // Title Case
  /^\d+(\.\d+)*\s+[A-Z]/, // Numbered sections
  /^[A-Z][a-z\s&]+(\s+[A-Z][a-z\s&]+)*$/ // Multiple Title Case Words
];

// Section indicators
export const SECTION_INDICATORS = [
  'admin',
  'user',
  'ui',
  'importing',
  'project details',
  'workflow',
  'privacy',
  'system activity',
  'home',
  'sequences',
  'templates',
  'snippets',
  'org settings',
  'permissions',
  'sfdc',
  'automations',
  'knowledge repository',
  'knowledge management', 
  'proposal generation',
  'information security',
  'operations security',
  'communications security',
  'system acquisition',
  'asset tracking',
  'data management',
  'financial & accounting',
  'planned services',
  'reporting'
];

// Worksheet patterns to skip
export const SKIP_WORKSHEETS = [
  'readme',
  'instructions',
  'notes',
  'changelog',
  'version history',
  'help',
  'guide'
];