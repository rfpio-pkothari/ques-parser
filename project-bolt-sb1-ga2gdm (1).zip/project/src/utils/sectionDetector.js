import { SECTION_PATTERNS, SECTION_INDICATORS } from './patterns.js';
import { TextCleaner } from './textCleaner.js';
import { QuestionDetector } from './questionDetector.js';

export class SectionDetector {
  static isSection(text, styles = {}) {
    if (!text || typeof text !== 'string' || text.length < 2) return false;
    
    const cleanText = TextCleaner.clean(text);
    const normalizedText = cleanText.toLowerCase();

    // Skip if it looks like a URL or link
    if (normalizedText.includes('http://') || normalizedText.includes('https://')) {
      return false;
    }

    // Skip if it looks like a question
    if (QuestionDetector.isQuestion(cleanText)) {
      return false;
    }

    // Check section indicators
    if (SECTION_INDICATORS.some(indicator => 
      normalizedText.includes(indicator.toLowerCase())
    )) {
      return true;
    }

    // Check formatting patterns
    return SECTION_PATTERNS.some(pattern => pattern.test(cleanText));
  }

  static validateSection(text) {
    if (!this.isSection(text)) return false;
    
    // Additional validation to ensure it's not a question
    const cleanText = TextCleaner.clean(text);
    if (cleanText.includes('?') || 
        QuestionDetector.isQuestion(cleanText) ||
        cleanText.length > 100) { // Sections are typically short
      return false;
    }
    
    return true;
  }
}