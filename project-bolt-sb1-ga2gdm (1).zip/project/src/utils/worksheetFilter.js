import { SKIP_WORKSHEETS } from './patterns.js';

export class WorksheetFilter {
  static shouldProcessWorksheet(sheetName) {
    if (!sheetName) return false;
    const normalizedName = sheetName.toLowerCase().trim();
    
    // Skip known non-question worksheets
    return !SKIP_WORKSHEETS.some(name => normalizedName.includes(name));
  }
}