import { QuestionDetector } from './questionDetector.js';
import { SectionDetector } from './sectionDetector.js';
import { ConfidenceCalculator } from './confidenceCalculator.js';
import { TextCleaner } from './textCleaner.js';

export class TextAnalyzer {
  static isSectionHeader(text, styles = {}) {
    return SectionDetector.isSection(text, styles);
  }

  static isQuestion(text) {
    return QuestionDetector.isQuestion(text);
  }

  static calculateConfidence(text) {
    return ConfidenceCalculator.calculate(text);
  }

  static cleanText(text) {
    return TextCleaner.clean(text);
  }

  static isDuplicate(questions, newQuestion) {
    return QuestionDetector.isDuplicate(questions, newQuestion);
  }
}