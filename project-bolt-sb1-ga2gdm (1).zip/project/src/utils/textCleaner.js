export class TextCleaner {
  static clean(text) {
    if (!text) return '';
    return text.toString()
      .replace(/\r\n|\r|\n/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  static normalize(text) {
    return this.clean(text).toLowerCase();
  }
}