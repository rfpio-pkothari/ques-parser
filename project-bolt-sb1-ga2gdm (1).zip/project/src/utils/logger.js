export class Logger {
  constructor() {
    this.logs = [];
  }

  add(message, type = 'info') {
    const log = {
      timestamp: new Date().toISOString(),
      type,
      message
    };
    this.logs.push(log);
    console.log(`[${log.type.toUpperCase()}] ${log.message}`);
    return log;
  }

  getLogs() {
    return this.logs;
  }

  clear() {
    this.logs = [];
  }
}