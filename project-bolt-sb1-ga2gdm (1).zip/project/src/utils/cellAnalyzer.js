export class CellAnalyzer {
  static analyzeCell(cell, workbook) {
    if (!cell) return null;

    const value = cell.v;
    const style = cell.s || {};
    
    return {
      value: value,
      isHeader: this.isHeaderStyle(style),
      isBold: style.font?.bold,
      fontSize: style.font?.sz,
      isWrapped: style.alignment?.wrapText,
      hasColor: !!style.fill?.fgColor,
      isFormula: cell.f !== undefined,
      dataType: this.getDataType(value)
    };
  }

  static isHeaderStyle(style) {
    return (
      style.font?.bold ||
      (style.font?.sz && style.font.sz > 11) ||
      style.fill?.fgColor ||
      style.border?.top?.style === 'medium' ||
      style.border?.bottom?.style === 'medium'
    );
  }

  static getDataType(value) {
    if (value === null || value === undefined) return 'empty';
    if (typeof value === 'number') return 'number';
    if (typeof value === 'boolean') return 'boolean';
    if (value instanceof Date) return 'date';
    if (typeof value === 'string') {
      if (/^\d{4}-\d{2}-\d{2}/.test(value)) return 'date';
      if (/^[0-9.]+$/.test(value)) return 'number';
      if (/^(yes|no|true|false)$/i.test(value)) return 'boolean';
      return 'text';
    }
    return 'unknown';
  }

  static isSectionHeader(cell) {
    if (!cell || !cell.value) return false;
    
    const value = cell.value.toString().trim();
    const style = cell.style || {};

    // Check formatting
    if (style.isBold || style.fontSize > 11 || style.hasColor) {
      return true;
    }

    // Check common section patterns
    return (
      /^[A-Z][A-Z\s]{2,}$/.test(value) || // ALL CAPS
      /^[A-Z][a-z]+(\s+-\s+[A-Z][a-z]+)+$/.test(value) || // Title-Case With Hyphens
      /^[IVX]+\.\s+/.test(value) || // Roman numerals
      /^\d+(\.\d+)*\s+[A-Z]/.test(value) // Numbered sections
    );
  }

  static isQuestion(cell) {
    if (!cell || !cell.value) return false;
    
    const value = cell.value.toString().trim();
    
    // Skip headers and metadata
    if (cell.isHeader || this.isMetadata(value)) {
      return false;
    }

    // Question patterns
    return (
      value.endsWith('?') ||
      /^(what|how|when|where|why|who|which|describe|explain|list|specify)/i.test(value) ||
      /^(ability\s+to|support\s+for|setup\s+of)/i.test(value) ||
      (/^[A-Za-z]/.test(value) && value.length > 20)
    );
  }

  static isMetadata(value) {
    return /^(version|date|author|category|section|priority|status|id):\s*/i.test(value);
  }
}