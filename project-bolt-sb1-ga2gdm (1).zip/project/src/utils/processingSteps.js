export class ProcessingSteps {
  constructor(logger) {
    this.logger = logger;
    this.steps = [];
    this.currentStep = 0;
    this.hasError = false;
  }

  addStep(title, description) {
    this.currentStep++;
    const step = {
      number: this.currentStep,
      title: title || 'Processing',
      description: description || '',
      timestamp: new Date().toISOString(),
      status: this.hasError ? 'error' : 'success',
      subSteps: []
    };
    this.steps.push(step);
    this.logger.add(`Step ${this.currentStep}: ${title} - ${description}`);
    return step;
  }

  addSubStep(description, status = 'success') {
    if (this.steps.length === 0) {
      this.addStep('Processing', 'Processing file contents');
    }
    
    const currentStep = this.steps[this.steps.length - 1];
    const subStep = {
      description: description || '',
      timestamp: new Date().toISOString(),
      status: status
    };
    
    currentStep.subSteps.push(subStep);
    this.logger.add(`  └─ ${description}`);
    return subStep;
  }

  markError() {
    this.hasError = true;
    if (this.steps.length > 0) {
      this.steps[this.steps.length - 1].status = 'error';
    }
  }

  getSteps() {
    if (this.steps.length === 0) {
      return [{
        number: 1,
        title: 'No Processing Steps',
        description: 'No processing steps were recorded',
        timestamp: new Date().toISOString(),
        status: 'error',
        subSteps: []
      }];
    }
    return this.steps;
  }

  clear() {
    this.steps = [];
    this.currentStep = 0;
    this.hasError = false;
  }
}