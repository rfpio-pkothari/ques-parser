import { QUESTION_PATTERNS, REQUIREMENT_VERBS, SKIP_PATTERNS } from './patterns.js';

export class QuestionDetector {
  static isQuestion(text, questionId = '') {
    if (!text || typeof text !== 'string') return false;
    const cleanText = text.trim();
    
    // Skip if too short
    if (cleanText.length < 5) return false;
    
    // Skip if matches skip patterns
    if (this.shouldSkip(cleanText)) return false;

    // For CAIQ format, check if there's a question ID (e.g., A&A-01.1)
    if (questionId && /^[A-Z&]+-\d+\.\d+$/.test(questionId.trim())) {
      return true;
    }

    // Check for question marks
    if (cleanText.includes('?')) return true;

    // Check for question patterns
    if (QUESTION_PATTERNS.some(pattern => pattern.test(cleanText))) {
      return true;
    }

    // Check for requirement verbs
    if (this.hasRequirementVerb(cleanText)) {
      return true;
    }

    // Accept longer statements that look like requirements
    return cleanText.length > 20 && /^(is|are|does|do|can|will|should|must|how|what|when|where|why|which)/i.test(cleanText);
  }

  static shouldSkip(text) {
    const normalized = text.toLowerCase().trim();
    
    // Skip patterns
    if (SKIP_PATTERNS.some(pattern => pattern.test(normalized))) {
      return true;
    }

    // Skip URLs and links
    if (normalized.includes('http://') || 
        normalized.includes('https://') ||
        normalized.includes('www.')) {
      return true;
    }

    // Skip very short responses
    if (normalized.split(' ').length < 3) {
      return true;
    }

    return false;
  }

  static hasRequirementVerb(text) {
    const normalized = text.toLowerCase();
    
    // Check for requirement-specific phrases
    const requirementPhrases = [
      'must have',
      'should have',
      'needs to',
      'required to',
      'ability to',
      'support for',
      'ensure',
      'verify',
      'validate',
      'implement'
    ];

    if (requirementPhrases.some(phrase => normalized.includes(phrase))) {
      return true;
    }

    // Check for requirement verbs
    return REQUIREMENT_VERBS.some(verb => 
      new RegExp(`\\b${verb}\\b`).test(normalized)
    );
  }
}