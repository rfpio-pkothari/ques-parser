import { QUESTION_PATTERNS, REQUIREMENT_VERBS, PRIORITY_INDICATORS } from './patterns.js';
import { TextCleaner } from './textCleaner.js';

export class ConfidenceCalculator {
  static calculate(text) {
    if (!text || typeof text !== 'string') return 0.3;
    
    let score = 0.3; // Base confidence
    const cleanText = TextCleaner.normalize(text);

    // Priority indicators boost confidence significantly
    if (PRIORITY_INDICATORS.some(indicator => 
      cleanText.includes(indicator.toLowerCase())
    )) {
      score += 0.3;
    }

    // Question indicators
    if (cleanText.endsWith('?')) score += 0.2;
    if (QUESTION_PATTERNS.some(pattern => pattern.test(cleanText))) score += 0.2;

    // Length-based confidence
    if (cleanText.length > 30) score += 0.1;
    if (cleanText.length > 60) score += 0.1;

    // Verb presence
    const verbCount = REQUIREMENT_VERBS.filter(verb => 
      new RegExp(`\\b${verb}\\b`, 'i').test(cleanText)
    ).length;
    score += Math.min(0.05 * verbCount, 0.2);

    // Technical terms or specific requirement indicators
    if (/\b(api|integration|workflow|automation|security|compliance)\b/i.test(cleanText)) {
      score += 0.1;
    }

    // CAIQ format confidence boost
    if (/^[A-Z&]+-\d+\.\d+/.test(cleanText)) {
      score += 0.2;
    }

    return Math.min(0.95, Math.max(0.3, score)); // Keep between 0.3 and 0.95
  }
}