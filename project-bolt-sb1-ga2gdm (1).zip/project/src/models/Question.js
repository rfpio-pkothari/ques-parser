import { TextCleaner } from '../utils/textCleaner.js';
import { ConfidenceCalculator } from '../utils/confidenceCalculator.js';

export class Question {
  constructor(id, worksheet, section, number, text) {
    this.id = id;
    this.worksheet = worksheet;
    this.section = section;
    this.questionNumber = number;
    this.text = TextCleaner.clean(text);
    this.confidence = ConfidenceCalculator.calculate(this.text);
  }

  toJSON() {
    return {
      id: this.id,
      worksheet: this.worksheet,
      section: this.section,
      questionNumber: this.questionNumber,
      text: this.text,
      confidence: this.confidence
    };
  }

  static fromRow(text, id, worksheet, section, number) {
    return new Question(id, worksheet, section, number, text);
  }
}