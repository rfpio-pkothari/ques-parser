import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import apiRoutes from './routes/api.js';
import { errorHandler } from './middleware/errorHandler.js';
import { Logger } from './utils/logger.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const uploadsDir = path.join(__dirname, '../uploads');
const logger = new Logger();

// Ensure uploads directory exists
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const app = express();

// Serve static files
app.use(express.static(path.join(__dirname, '../public')));

// API routes
app.use('/api', apiRoutes);

// Error handling
app.use(errorHandler);

const PORT = process.env.PORT || 3000;

// Validate server startup
try {
  app.listen(PORT, () => {
    logger.add(`Server running on port ${PORT}`);
  });
} catch (error) {
  logger.add(`Failed to start server: ${error.message}`, 'error');
  process.exit(1);
}

export default app;