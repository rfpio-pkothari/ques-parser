import express from 'express';
import { Parser } from 'json2csv';
import { upload } from '../middleware/upload.js';
import { ExcelParser } from '../services/excelParser.js';
import { Logger } from '../utils/logger.js';
import { ERROR_MESSAGES } from '../config/constants.js';

const router = express.Router();
const logger = new Logger();
let lastParsedData = null;

router.post('/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      throw new Error(ERROR_MESSAGES.NO_FILE);
    }

    logger.add('Starting file processing');
    const parser = new ExcelParser();
    const result = await parser.parse(req.file.path);
    
    if (!result.success) {
      throw new Error(result.error || 'Failed to process file');
    }
    
    lastParsedData = result;
    logger.add('File processing completed');
    
    // Send JSON response with proper headers
    res.setHeader('Content-Type', 'application/json');
    res.json({
      success: true,
      questions: result.questions || [],
      stats: result.stats || {},
      steps: result.steps || []
    });
  } catch (error) {
    logger.add(`Error: ${error.message}`, 'error');
    res.status(400).json({
      success: false,
      error: error.message,
      questions: [],
      stats: {
        total_worksheets: 0,
        total_sections: 0,
        total_questions: 0
      },
      steps: [{
        number: 1,
        title: 'Error',
        description: error.message,
        status: 'error'
      }]
    });
  }
});

router.get('/download/json', (req, res) => {
  if (!lastParsedData?.questions?.length) {
    return res.status(404).json({ error: ERROR_MESSAGES.NO_DATA });
  }

  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', 'attachment; filename=questions.json');
  res.json(lastParsedData.questions);
});

router.get('/download/csv', (req, res) => {
  if (!lastParsedData?.questions?.length) {
    return res.status(404).json({ error: ERROR_MESSAGES.NO_DATA });
  }

  const parser = new Parser({
    fields: ['id', 'worksheet', 'section', 'questionNumber', 'text', 'confidence']
  });

  const csv = parser.parse(lastParsedData.questions);
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename=questions.csv');
  res.send(csv);
});

export default router;