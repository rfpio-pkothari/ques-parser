from flask import Flask, request, render_template, jsonify
import openpyxl
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def is_section_header(row):
    """Determine if a row is likely a section header based on formatting"""
    return any(cell.font and (cell.font.bold or cell.font.size > 11) for cell in row if cell.value)

def parse_excel(filepath):
    """Parse the Excel file and extract worksheet, section, and question data"""
    workbook = openpyxl.load_workbook(filepath, data_only=True)
    result = {}
    stats = {
        'total_worksheets': len(workbook.sheetnames),
        'total_sections': 0,
        'total_questions': 0
    }
    
    for sheet_name in workbook.sheetnames:
        sheet = workbook[sheet_name]
        result[sheet_name] = []
        current_section = None
        
        for row in sheet.iter_rows():
            # Skip empty rows
            if not any(cell.value for cell in row):
                continue
                
            # Check if this is a section header
            if is_section_header(row):
                current_section = next((cell.value for cell in row if cell.value), "Unnamed Section")
                result[sheet_name].append({
                    "section": current_section,
                    "questions": []
                })
                stats['total_sections'] += 1
            
            # If we have content and it's not a header, treat it as a question
            elif current_section and any(cell.value for cell in row):
                question_text = next((cell.value for cell in row if cell.value), "")
                if question_text:
                    result[sheet_name][-1]["questions"].append(question_text)
                    stats['total_questions'] += 1
    
    return result, stats

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if not file.filename.endswith(('.xlsx', '.xls')):
        return jsonify({'error': 'Invalid file format'}), 400
    
    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)
    
    try:
        result, stats = parse_excel(filepath)
        os.remove(filepath)  # Clean up the uploaded file
        return jsonify({
            'success': True,
            'data': result,
            'stats': stats
        })
    except Exception as e:
        os.remove(filepath)  # Clean up the uploaded file
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)